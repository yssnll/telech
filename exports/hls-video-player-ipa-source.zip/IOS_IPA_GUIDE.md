# HLS Video Player — préparation d’une vraie IPA iOS

## Ce que contient cette archive

- `artifacts/hls-video-player/` : l’application Expo mobile, son écran vidéo, les téléchargements en arrière-plan et les assets iOS.
- `artifacts/api-server/` : le service nécessaire à la conversion HLS vers MP4.
- `lib/` : les contrats API et les bibliothèques partagées utilisés par l’app et le serveur.
- `pnpm-lock.yaml` : les versions exactes des dépendances.

## Pourquoi il n’y a pas de dossier `ios/` ni de fichiers Swift

Le projet utilise Expo en mode géré. Les fichiers Swift, Objective-C, Xcode, Pods et le projet `ios/` sont générés automatiquement au moment du build iOS à partir de `artifacts/hls-video-player/app.json`.

Les ajouter manuellement dans cette archive créerait un projet natif figé et potentiellement incompatible avec les versions Expo du projet.

## Obtenir une vraie IPA

Le chemin recommandé est le flux de publication iOS de Replit :

1. Importer cette archive ou continuer depuis le projet source.
2. Configurer le compte Apple Developer et l’identifiant d’application iOS.
3. Dans la publication mobile, choisir le démarrage de la publication vers l’App Store.
4. Le build génère automatiquement le projet natif, le signe et produit une IPA installable / envoyée vers App Store Connect et TestFlight.

L’IPA ne peut pas être fabriquée uniquement avec un ZIP : Apple exige un compte développeur, des certificats et une signature iOS associée à l’équipe Apple.

## Point important pour le serveur

L’application mobile appelle le service API configuré par `EXPO_PUBLIC_DOMAIN`. Le serveur API doit donc être déployé séparément et accessible publiquement pour que la lecture HLS relayée et la conversion MP4 fonctionnent dans l’IPA.
